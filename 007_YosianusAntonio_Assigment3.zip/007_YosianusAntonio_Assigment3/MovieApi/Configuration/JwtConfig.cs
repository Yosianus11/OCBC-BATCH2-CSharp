using System;

namespace MovieApi.Configuration
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}