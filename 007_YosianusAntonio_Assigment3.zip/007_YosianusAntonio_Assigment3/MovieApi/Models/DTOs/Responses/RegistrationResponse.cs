using MovieApi.Configuration;

namespace MovieApi.Models.DTOs.Responses{
    public class RegistrationResponse: AuthResult{
        
    }
}