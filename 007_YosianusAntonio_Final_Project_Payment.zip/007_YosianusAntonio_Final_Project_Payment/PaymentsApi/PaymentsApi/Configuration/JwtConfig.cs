﻿using System;

namespace PaymentsApi.Configuration
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}