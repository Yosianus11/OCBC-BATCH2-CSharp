﻿using PaymentsApi.Configuration;

namespace PaymentsApi.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {

    }
}